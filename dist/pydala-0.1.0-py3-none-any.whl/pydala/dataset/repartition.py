import pyarrow as pa

from .helper import get_ddb_sort_str
from .reader import Reader
from .writer import Writer


class Repartition:
    def __init__(
        self,
        reader: Reader,
        writer: Writer,
        caching_method: str = "local",  # or temp_table
        source_table: str = "mem_table",  # or temp_table or dataset
        schema_auto_conversion: bool = True,
    ):
        self._reader = reader
        self._writer = writer

        self._caching_method = caching_method
        self._source_table = source_table
        self._row_group_size = None
        self._batch_size = None
        self._overwrite = False
        self._schema = None
        self._mode = "raise"
        self._schema_auto_conversion = schema_auto_conversion

    def read(self):
        if self._schema_auto_conversion:
            self._reader.set_pyarrow_schema()
            self._schema = self._reader._schema

        if self._reader._path == self._writer._base_path:
            self._writer._mode = "overwrite"

            if self._caching_method == "local":
                self._reader._to_cache()

            elif self._caching_method == "temp_table":
                self._reader.create_temp_table()

            else:
                raise ValueError(
                    f"{self._caching_method} is not a valid value for caching_method. "
                    "Must be 'local' or 'mem_table'."
                )

        if self._source_table == "mem_table":
            if not self._reader.has_mem_table:
                self._reader.load_mem_table()

        elif self._source_table == "dataset":
            if not self._reader.has_dataset:
                self._source_table = self._reader.load_dataset()

        elif self._source_table == "temp_table":
            if self._reader.has_temp_table:
                self._reader.create_temp_table()

        else:
            raise ValueError(
                f"{self._source_table} is not a valid value for source_table. "
                "Must be 'local' or 'mem_table'."
            )

        self._source = self._reader.rel

    def _delete_source(self):
        if self._reader.cached:
            self._reader._fs.rm(self._reader._path, recursive=True)

    def sort(self, by: str | list | None, ascending: bool | list | None = None):
        self._writer._sort_by = by

        if ascending is None:
            ascending = True
        self._writer._ascending = ascending

        if self._writer._sort_by is not None:
            self._writer._sort_by_ddb = get_ddb_sort_str(
                sort_by=by, ascending=ascending
            )

        return self

    def distinct(self, value: bool | None):
        if value is None:
            value = False
        self._writer._distinct = value

        return self

    def drop(self, columns: str | list | None):
        self._writer._drop = columns

        return self

    def partitioning(
        self, columns: str | list | None = None, flavor: str | None = None
    ):
        if columns is not None:
            if isinstance(columns, str):
                columns = [columns]
            self._writer._partitioning = columns

        if flavor is not None:
            self._writer._partitioning_flavor = flavor

        return self

    def compression(self, value: str | None = None):
        self._writer._compression = value

        return self

    def format(self, value: str | None = None):
        if value is not None:
            self._writer._format = value

        return self

    def mode(self, value: str | None):
        if value is not None:
            if value not in ["overwrite", "append", "raise"]:
                raise ValueError(
                    "Value for mode must be 'overwrite', 'raise' or 'append'."
                )
            else:
                self._writer._mode = value

        return self

    def batch_size(self, value: int | str | None = None):
        if value is not None:
            self._batch_size = value

        return self

    def row_group_size(self, value: int | None = None):
        if value is not None:
            self._row_group_size = value

        return self

    def schema(self, schema: pa.Schema | None = None):
        if schema is not None:
            self._schema = schema
        return self

    def write(
        self,
        batch_size: str | int | None = None,
        row_group_size: int | None = None,
        sort_by: str | None = None,
        ascending: bool | None = None,
        distinct: bool | None = None,
        drop: str | list | None = None,
        partitioning: str | list | None = None,
        partitioning_flavor: str | None = None,
        compression: str | None = None,
        format: str | None = None,
        schema: pa.Schema | None = None,
        mode: str | None = None,
        delete_source: bool = True,
        datetime_column: str | None = None,
    ):
        self.sort(by=sort_by, ascending=ascending)
        self.distinct(value=distinct)
        self.drop(columns=drop)
        self.partitioning(columns=partitioning, flavor=partitioning_flavor)
        self.compression(value=compression)
        self.format(value=format)
        self.schema(schema=schema)
        self.mode(value=mode)
        self.batch_size(value=batch_size)
        self.row_group_size(value=row_group_size)
        self._writer.write_dataset(
            table=self._source,
            batch_size=self._batch_size,
            row_group_size=self._row_group_size,
            datetime_column=datetime_column,
        )
        if delete_source:
            self._delete_source()

# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['pydatalake', 'pydatalake.dataset']

package_data = \
{'': ['*']}

install_requires = \
['duckdb>=0.5.1,<0.6.0',
 'joblib>=1.2.0,<2.0.0',
 'pandas>=1.5.0,<2.0.0',
 'pathlib>=1.0.1,<2.0.0',
 'polars>=0.14.18,<0.15.0',
 'pyarrow>=9.0.0,<10.0.0',
 's3fs>=2022.8.2,<2023.0.0']

setup_kwargs = {
    'name': 'pydatalake',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Volker Lorrmann',
    'author_email': 'volker.lorrmann@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)

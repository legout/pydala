from pathlib import Path
import pyarrow.fs as fs
import pyarrow as pa
import s3fs
import duckdb

def path_exists(path:str, filesystem: fs.FileSystem | s3fs.S3FileSystem |None = None) -> bool:
    if filesystem is not None:
        if hasattr(filesystem, "exists"):
            return filesystem.exists(path)
        else:
            return filesystem.get_file_info(path).type > 0
    else:
        return Path(path).exists()


def is_file(path:str,    filesystem: fs.FileSystem | s3fs.S3FileSystem |None = None,
) -> bool:
    if filesystem is not None:
        if hasattr(filesystem, "isfile"):
            return filesystem.isfile(path)
        else:
            return filesystem.get_file_info(path).type == 2
    else:
        return Path(path).is_file()


def sort_pa_table(table_:pa.Table, sort_by:str|list, ddb:duckdb.DuckDBPyConnection):
    
    if isinstance(sort_by, list):
        sort_by = ",".join(sort_by)
        
    return ddb.execute(f"SELECT * FROM table_ ORDER BY {sort_by}").arrow()
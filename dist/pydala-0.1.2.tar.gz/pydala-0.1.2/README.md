# PyDaLa

>Poor man's simple python api for creating a local or remote datalake based on several (pyarrow) datasets using duckdb

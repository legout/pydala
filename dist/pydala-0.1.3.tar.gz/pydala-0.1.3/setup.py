# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['pydala',
 'pydala.datalake',
 'pydala.dataset',
 'pydala.filesystem',
 'pydala.utils']

package_data = \
{'': ['*']}

install_requires = \
['duckdb>=0.6.0,<0.7.0',
 'fsspec>=2022.11.0,<2023.0.0',
 'numpy>=1.23.5,<2.0.0',
 'pandas>=1.5.2,<2.0.0',
 'polars>=0.15.1,<0.16.0',
 'progressbar2>=4.2.0,<5.0.0',
 'pyarrow>=10.0.0,<11.0.0',
 'rtoml>=0.9.0,<0.10.0',
 's3fs>=2022.11.0,<2023.0.0',
 'typer>=0.7.0,<0.8.0']

setup_kwargs = {
    'name': 'pydala',
    'version': '0.1.3',
    'description': "Poor man's simple python api for creating a local or remote datalake based on several (pyarrow) datasets using duckdb",
    'long_description': "# PyDaLa\n\n>Poor man's simple python api for creating a local or remote datalake based on several (pyarrow) datasets using duckdb\n",
    'author': 'Volker Lorrmann',
    'author_email': 'volker.lorrmann@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)

import random
import string

import duckdb
import pandas as pd
import polars as pl
import pyarrow as pa
import pyarrow.dataset as ds
from fsspec import spec
from fsspec.utils import infer_storage_options
from pyarrow.fs import FileSystem

from ..filesystem.base import fsspec_filesystem, pyarrow_filesystem
from ..filesystem.dirfs import fsspec_dir_filesystem, pyarrow_subtree_filesystem


def get_filesystem(
    bucket: str | None,
    protocol: str,
    profile: str | None,
    endpoint_url: str | None,
    storage_options: dict | None,
    caching: bool,
    cache_bucket: str | None,
    fsspec_fs: spec.AbstractFileSystem | None,
    pyarrow_fs: FileSystem | None,
    use_pyarrow_fs: bool = False,
):

    filesystem = {}

    if fsspec_fs:
        filesystem["fsspec_main"] = fsspec_fs
    else:
        filesystem["fsspec_main"] = fsspec_filesystem(
            protocol=protocol,
            profile=profile,
            endpoint_url=endpoint_url,
            **storage_options,
        )
    if use_pyarrow_fs:
        if pyarrow_fs:
            filesystem["pyarrow_main"] = pyarrow_fs
        else:
            filesystem["pyarrow_main"] = pyarrow_filesystem(
                protocol=protocol,
                endpoint_url=endpoint_url,
                **storage_options,
            )

    if bucket:
        if hasattr(filesystem["fsspec_main"], "path"):
            filesystem["fsspec_main"] = fsspec_dir_filesystem(
                path=bucket, filesystem=filesystem["fsspec_main"].fs
            )
        else:
            filesystem["fsspec_main"] = fsspec_dir_filesystem(
                path=bucket, filesystem=filesystem["fsspec_main"]
            )
        if use_pyarrow_fs:
            if hasattr(filesystem["pyarrow_main"], "base_path"):
                filesystem["pyarrow_main"] = pyarrow_subtree_filesystem(
                    path=bucket, filesystem=filesystem["pyarrow_main"].base_fs
                )
            else:
                filesystem["pyarrow_main"] = pyarrow_subtree_filesystem(
                    path=bucket, filesystem=filesystem["pyarrow_main"]
                )

    if caching:
        cache_bucket = cache_bucket or ""
        filesystem["fsspec_cache"] = fsspec_dir_filesystem(
            path=cache_bucket,
            filesystem=fsspec_filesystem(protocol="file"),
        )
        if use_pyarrow_fs:
            filesystem["pyarrow_cache"] = pyarrow_subtree_filesystem(
                path=cache_bucket,
                filesystem=pyarrow_filesystem(protocol="file"),
            )
    return filesystem


def get_ddb_sort_str(sort_by: str | list, ascending: bool | list | None = None) -> str:
    ascending = ascending or True
    if isinstance(sort_by, list):

        if isinstance(ascending, bool):
            ascending = [ascending] * len(sort_by)

        sort_by_ddb = [
            f"{col} ASC" if asc else f"{col} DESC"
            for col, asc in zip(sort_by, ascending)
        ]
        sort_by_ddb = ",".join(sort_by_ddb)

    else:
        sort_by_ddb = sort_by + " ASC" if ascending else sort_by + " DESC"

    return sort_by_ddb


def to_polars(
    table: pa.Table
    | pd.DataFrame
    | pl.DataFrame
    | duckdb.DuckDBPyRelation
    | ds.FileSystemDataset,
) -> pl.DataFrame:

    if isinstance(table, pa.Table):
        pl_dataframe = pl.from_arrow(table)

    elif isinstance(table, pd.DataFrame):
        pl_dataframe = pl.from_pandas(table)

    elif isinstance(table, ds.FileSystemDataset):
        pl_dataframe = pl.from_arrow(table.to_table())

    elif isinstance(table, duckdb.DuckDBPyRelation):
        pl_dataframe = pl.from_arrow(table.arrow())

    else:
        pl_dataframe = table

    return pl_dataframe


def to_pandas(
    table: pa.Table
    | pd.DataFrame
    | pl.DataFrame
    | duckdb.DuckDBPyRelation
    | ds.FileSystemDataset,
) -> pd.DataFrame:

    if isinstance(table, pa.Table):
        pd_dataframe = table.to_pandas()

    elif isinstance(table, pl.DataFrame):
        pd_dataframe = table.to_pandas()

    elif isinstance(table, ds.FileSystemDataset):
        pd_dataframe = table.to_table().to_pandas()

    elif isinstance(table, duckdb.DuckDBPyRelation):
        pd_dataframe = table.df()

    else:
        pd_dataframe = table

    return pd_dataframe


def to_relation(
    table: duckdb.DuckDBPyRelation
    | pa.Table
    | ds.FileSystemDataset
    | pd.DataFrame
    | pl.DataFrame
    | str,
    ddb: duckdb.DuckDBPyConnection,
    # sort_by: str | list | None = None,
    # ascending: bool | list | None = None,
    # distinct: bool = False,
    # drop: str | list | None = None,
) -> duckdb.DuckDBPyRelation:

    if isinstance(table, pa.Table):
        # if distinct:
        #    table = distinct_table(table)

        # if sort_by:
        #    table = sort_table(
        #        drop_columns(table=table, columns=drop),
        #        sort_by=sort_by,
        #        ascending=ascending,
        #    )

        return ddb.from_arrow(table)

    elif isinstance(table, ds.FileSystemDataset):

        table = ddb.from_arrow(table)

        # if distinct:
        #    table = table.distinct()

        # if drop:
        #    table = drop_columns(table, columns=drop)

        # if sort_by:
        #    sort_by = get_ddb_sort_str(sort_by=sort_by, ascending=ascending)
        #    table = table.order(sort_by)

        return table

    elif isinstance(table, pd.DataFrame):

        # if distinct:
        #    table = distinct_table(table)

        # if sort_by:
        #    table = sort_table(
        #        drop_columns(table, columns=drop), sort_by=sort_by, ascending=ascending
        #    )

        return ddb.from_df(table)

    elif isinstance(table, pl.DataFrame):

        # if distinct:
        #    table = distinct_table(table)

        # if sort_by:
        #    table = sort_table(
        #        drop_columns(table, columns=drop),
        #        sort_by=sort_by,
        #        ascending=ascending,
        #        ddb=ddb,
        #    )

        return ddb.from_arrow(table.to_arrow())

    elif isinstance(table, str):
        if ".parquet" in table:
            table = ddb.from_parquet(table)
        elif ".csv" in table:
            table = ddb.from_csv_auto(table)
        else:
            table = ddb.query(f"SELECT * FROM '{table}'")

        # if distinct:
        #    table = table.distinct()

        # if drop:
        #    table = drop_columns(table, columns=drop)

        # if sort_by:
        #    sort_by = get_ddb_sort_str(sort_by=sort_by, ascending=ascending)
        #    table = table.order(sort_by)

        return table

    elif isinstance(table, duckdb.DuckDBPyRelation):
        table = table

        # if sort_by:
        #    sort_by = get_ddb_sort_str(sort_by=sort_by, ascending=ascending)
        #    table = table.order(sort_by)

        # if distinct:
        #    table = table.distinct()

        return table


def sort_table(
    table: pa.Table
    | pd.DataFrame
    | pl.DataFrame
    | duckdb.DuckDBPyRelation
    | ds.FileSystemDataset,
    sort_by: str | list | tuple | None,
    ascending: bool | list | tuple | None,
    ddb: duckdb.DuckDBPyConnection | None = None,
) -> pa.Table | pd.DataFrame | pl.DataFrame | duckdb.DuckDBPyRelation:

    if sort_by:
        ascending = ascending or True

        if isinstance(ascending, bool):
            reverse = not ascending
        else:
            reverse = [not el for el in ascending]

        if isinstance(table, pa.Table):

            return to_polars(table=table).sort(by=sort_by, reverse=reverse).to_arrow()

        elif isinstance(table, pd.DataFrame):
            return to_polars(table=table).sort(by=sort_by, reverse=reverse).to_pandas()

        elif isinstance(table, ds.FileSystemDataset):
            return to_polars(table=table).sort(by=sort_by, reverse=reverse).to_arrow()

        elif isinstance(table, pl.DataFrame):
            return table.sort(by=sort_by, reverse=reverse)

        elif isinstance(table, duckdb.DuckDBPyRelation):
            return ddb.from_arrow(
                to_polars(table).sort(by=sort_by, reverse=reverse).to_arrow()
            )
    else:
        return table


def get_tables_diff(
    table1: pa.Table
    | pd.DataFrame
    | pl.DataFrame
    | duckdb.DuckDBPyRelation
    | ds.FileSystemDataset
    | str,
    table2: pa.Table
    | pd.DataFrame
    | pl.DataFrame
    | duckdb.DuckDBPyRelation
    | ds.FileSystemDataset
    | str,
    subset: list | None = None,
    cast_as_str: bool = False,
    ddb: duckdb.DuckDBPyConnection | None = None,
) -> pa.Table | pd.DataFrame | pl.DataFrame | duckdb.DuckDBPyRelation:

    if not ddb: # is None:
        ddb = duckdb.connect()

    table1_ = to_relation(table1, ddb=ddb)
    table2_ = to_relation(table2, ddb=ddb)

    if subset:
        print(subset)
        if cast_as_str:
            subset_types = table1_.project(",".join(subset)).types
            subset_table1_ = table1_.project(
                ",".join([f"CAST({col} as STRING) as {col}" for col in subset])
            )
            subset_table2_ = table2_.project(
                ",".join([f"CAST({col} as STRING) as {col}" for col in subset])
            )
        else:
            subset_types = None
            subset_table1_ = table1_.project(",".join(subset))
            subset_table2_ = table2_.project(",".join(subset))

        diff_ = subset_table1_.except_(subset_table2_)  # .arrow().to_pylist()
        if subset_types:
            diff_ = diff_.project(
                ",".join(
                    [
                        f"CAST({col} as {type_}) as {col}"
                        for col, type_ in zip(subset, subset_types)
                    ]
                )
            )

        diff = to_polars(table1).filter(
            pl.struct(subset).is_in(diff_.arrow().to_pylist())
        )

    else:
        print("No subset given")
        diff = table1_.except_(table2_.project(",".join(table1_.columns)))

    if isinstance(table1, (pa.Table, ds.FileSystemDataset)):
        if isinstance(diff, pl.DataFrame):
            return diff.to_arrow()
        else:
            return diff.arrow()

    elif isinstance(table1, pd.DataFrame):
        return to_pandas(diff)

    elif isinstance(table1, pl.DataFrame):
        return to_polars(diff)

    elif isinstance(table1, duckdb.DuckDBPyRelation):
        return to_relation(diff, ddb=ddb)

    else:
        if isinstance(diff, pl.DataFrame):
            return diff.to_arrow()
        else:
            return diff.arrow()

    # if type(table1) != type(table2):
    #    raise TypeError

    # else:
    #     if isinstance(table1, pa.Table):
    #         return ddb.from_arrow(table1).except_(ddb.from_arrow(table2)).arrow()
    #     elif isinstance(table1, pd.DataFrame):
    #         return ddb.from_df(table1).except_(ddb.from_df(table2)).df()
    #     elif isinstance(table1, pl.DataFrame):
    #         return pl.concat([table1.with_row_count(), table2.with_row_count()]).filter(
    #             pl.count().over(table1.columns) == 1
    #         )
    #     elif isinstance(table1, str):
    #         return ddb.execute(
    #             f"SELECT * FROM {table1} EXCEPT SELECT * FROM {table2}"
    #         ).arrow()


def distinct_table(
    table: pa.Table
    | pd.DataFrame
    | pl.DataFrame
    | duckdb.DuckDBPyRelation
    | ds.FileSystemDataset,
    ddb: duckdb.DuckDBPyConnection | None = None,
) -> pa.Table | pd.DataFrame | pl.DataFrame | duckdb.DuckDBPyRelation:

    if isinstance(table, pa.Table):
        table = to_polars(table=table)
        if not table.is_unique().all():
            return table.unique().to_arrow()
        else:
            return table.to_arrow()

    elif isinstance(table, pd.DataFrame):
        table = to_polars(table=table)
        if not table.is_unique().all():
            return table.unique().to_pandas()
        else:
            return table.to_pandas()

    elif isinstance(table, ds.FileSystemDataset):
        table = to_polars(table=table)
        if not table.is_unique().all():
            return table.unique().to_arrow()
        else:
            return table.to_arrow()

    elif isinstance(table, pl.DataFrame):
        if not table.is_unique().all():
            return table.unique().to_arrow()
        else:
            return table.to_arrow()

    elif isinstance(table, duckdb.DuckDBPyRelation):
        table = to_polars(table=table)
        if not table.is_unique().all():
            return ddb.from_arrow(table.unique().to_arrow())
        else:
            return ddb.from_arrow(table.to_arrow())


def drop_columns(
    table: pa.Table
    | pd.DataFrame
    | pl.DataFrame
    | duckdb.DuckDBPyRelation
    | ds.FileSystemDataset,
    columns: str | list | None = None,
) -> pa.Table | pd.DataFrame | pl.DataFrame | duckdb.DuckDBPyRelation:
    if isinstance(columns, str):
        columns = [columns]

    if columns:
        if isinstance(table, pa.Table):
            columns = [col for col in columns if col in table.column_names]
            if len(columns) > 0:
                return table.drop(columns=columns)
            return table

        elif isinstance(table, (pl.DataFrame, pd.DataFrame)):
            columns = [col for col in columns if col in table.columns]
            if len(columns) > 0:
                return table.drop(columns=columns)
            return table

        elif isinstance(table, ds.FileSystemDataset):
            columns = [col for col in table.schema.names if col not in columns]
            if len(columns) > 0:
                return table.to_table(columns=columns)
            return table.to_table()

        elif isinstance(table, duckdb.DuckDBPyRelation):
            columns = [
                f"'{col}'" if " " in col else col
                for col in table.columns
                if col not in columns
            ]
            if len(columns) > 0:
                return table.project(",".join(columns))
            return table
    else:
        return table


def _pyarrow_schema_auto_conversion(
    schema1: pa.Schema, schema2: pa.Schema
) -> tuple[dict, bool]:
    schema = []
    schemas_equal = True
    dtype_rank = [
        pa.int8(),
        pa.int16(),
        pa.int32(),
        pa.int64(),
        pa.float16(),
        pa.float32(),
        pa.float64(),
        pa.string(),
    ]
    for name in schema1.names:
        type1 = schema1.field(name).type
        type2 = schema2.field(name).type

        if type1 != type2:
            schemas_equal = False
            if type1 in dtype_rank:
                rank1 = dtype_rank.index(type1)
            else:
                rank1 = 0
            if type2 in dtype_rank:
                rank2 = dtype_rank.index(type2)
            else:
                rank2 = 0

            schema.append(pa.field(name, type1 if rank1 > rank2 else type2))

        else:
            schema.append(pa.field(name, type1))

    return pa.schema(schema), schemas_equal


def _polars_schema_auto_conversion(schema1: dict, schema2: dict) -> tuple[dict, bool]:
    schema = {}
    schemas_equal = True
    dtype_rank = [
        pl.Int8(),
        pl.Int16(),
        pl.Int32(),
        pl.Int64(),
        pl.Float32(),
        pl.Float64(),
        pl.Utf8(),
    ]

    for name in schema1:
        type1 = schema1[name]
        type2 = schema2[name]

        if type1 != type2:
            schemas_equal = False
            if type1 in dtype_rank:
                rank1 = dtype_rank.index(type1)
            else:
                rank1 = 0
            if type2 in dtype_rank:
                rank2 = dtype_rank.index(type2)
            else:
                rank2 = 0

            schema[name] = type1 if rank1 > rank2 else type2

        else:
            schema[name] = type1
    return schema, schemas_equal


def schema_auto_conversion(schemas: list[pa.Schema] | list[dict]):
    schemas_equal = True
    schema = schemas[0]
    for schema2 in schemas[1:]:
        schema, schemas_qual_ = (
            _pyarrow_schema_auto_conversion(schema, schema2)
            if isinstance(schema, pa.Schema)
            else _polars_schema_auto_conversion(schema, schema2)
        )

        if not schemas_qual_:
            schemas_equal = schemas_qual_

    return schema, schemas_equal


def random_id():
    alphabet = string.ascii_lowercase + string.digits
    return "".join(random.choices(alphabet, k=8))


def convert_size_unit(size, unit="MB"):
    if unit == "B":
        return round(size, 1)
    elif unit == "KB":
        return round(size / 1024, 1)
    elif unit == "MB":
        return round(size / 1024**2, 1)
    elif unit == "GB":
        return round(size / 1024**3, 1)
    elif unit == "TB":
        return round(size / 1024**4, 1)
    elif unit == "PB":
        return round(size / 1024**5, 1)


def get_storage_path_options(
    bucket: str | None, path: str | None, protocol: str | None
):
    if bucket:
        protocol = protocol or infer_storage_options(bucket)["protocol"]
        bucket = infer_storage_options(bucket)["path"]
    else:
        bucket = None
        protocol = protocol or infer_storage_options(path)["protocol"]

    path = infer_storage_options(path)["path"]

    return bucket, path, protocol


class NestedDictReplacer:
    def __init__(self, d: dict) -> None:
        self._d = d

    def _dict_replace_value(self, d: dict, old: str | None, new: str | None) -> dict:
        x = {}
        for k, v in d.items():
            if isinstance(v, dict):
                v = self._dict_replace_value(v, old, new)
            elif isinstance(v, list):
                v = self._list_replace_value(v, old, new)
            else:
                v = v if v != old else new
            x[k] = v
        return x

    def _list_replace_value(self, l: list, old: str | None, new: str | None) -> list:
        x = []
        for e in l:
            if isinstance(e, list):
                e = self._list_replace_value(e, old, new)
            elif isinstance(e, dict):
                e = self._dict_replace_value(e, old, new)
            else:
                e = e if e != old else new
            x.append(e)
        return x

    def replace(self, old: str | None, new: str | None) -> dict:
        d = self._d
        return self._dict_replace_value(d, old, new)

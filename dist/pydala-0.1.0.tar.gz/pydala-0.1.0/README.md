# PyDaLa

Poor mans simple python api for creating a local or remote datalake based on several (pyarrow) datasets using duckdb
import duckdb
import pandas as pd
import polars as pl
import pyarrow as pa
import pyarrow.dataset as ds
import pyarrow.fs as pafs
import s3fs

from .reader import Reader
from .writer import Writer
from .utils import to_ddb_relation, copy_to_tmp_directory


def repartition(
    src: str,
    dest: str,
    base_name: str = "data",
    partitioning: list | str | dict | None = None,
    format: str | list | tuple | dict | None = "parquet",
    filesystem: pafs.FileSystem | s3fs.S3FileSystem | list | tuple | dict | None = None,
    compression: str | None = "zstd",
    rows_per_file: int | None = None,
    row_group_size: int | None = None,
    sort_by: str | list | None = None,
    distinct: bool = False,
    append: bool = True,
    with_time_partition: bool = False,
    with_temp_table: bool = False,
    with_mem_table: bool = False,
    use_tmp_directory: bool = False,
    delete_old_files: bool = False,
    **kwargs,
):
    ddb = duckdb.connect()

    if isinstance(partitioning, (list, tuple)):
        partitioning_reader = partitioning[0]
        partitioning_writer = partitioning[1]
    elif isinstance(partitioning, dict):
        partitioning_reader = partitioning["reader"]
        partitioning_writer = partitioning["writer"]
    else:
        partitioning_reader = partitioning
        partitioning_writer = partitioning

    if isinstance(format, (list, tuple)):
        format_reader = format[0]
        format_writer = format[1]
    elif isinstance(partitioning, dict):
        format_reader = format["reader"]
        format_writer = format["writer"]
    else:
        format_reader = format
        format_writer = format

    if isinstance(filesystem, (list, tuple)):
        filesystem_reader = filesystem[0]
        filesystem_writer = filesystem[1]
    elif isinstance(filesystem, dict):
        filesystem_reader = filesystem["reader"]
        filesystem_writer = filesystem["writer"]
    else:
        filesystem_reader = filesystem
        filesystemwriter = filesystem

    reader = Reader(
        path=src,
        filesystem=filesystem_reader,
        partitioning=partitioning_reader,
        format=format_reader,
        sort_by=sort_by,
        ddb=ddb,
    )

    if with_temp_table:
        reader.create_temp_table

    writer = Writer(
        path=dest,
        filesystem=filesystem_writer,
        partitioning=partitioning_writer,
        compression=compression,
        sort_by=sort_by,
        ddb=ddb,
    )
